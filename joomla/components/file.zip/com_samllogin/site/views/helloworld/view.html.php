<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_helloworld
 *
 * @copyright   Copyright (C) 2005 - 2019 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * HTML View class for the HelloWorld Component
 *
 * @since  0.0.1
 */
class HelloWorldViewHelloWorld extends JViewLegacy
{
  function random_str($length = 64, $keyspace = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ') {
    if ($length < 1) {
      $length = 64;
    }
    $pieces = [];
    $max = mb_strlen($keyspace, '8bit') - 1;
    for ($i = 0; $i < $length; ++$i) {
      $pieces []= $keyspace[random_int(0, $max)];
    }
    return implode('', $pieces);
  }


	/**
	 * Display the Hello World view
	 *
	 * @param   string  $tpl  The name of the template file to parse; automatically searches through the template paths.
	 *
	 * @return  void
	 */
	function display($tpl = null) {
    $id = JFactory::getUser()->id;        // Get the user object
    $app  = JFactory::getApplication(); // Get the application

    //'&redirect_uri='.urlencode(\SimpleSAML\Module::getModuleURL('authwindowslive').'/linkback.php').
    //'&state='.urlencode($stateID).
    //$this->msg="Accedi con il tuo account della scuola per proseguire.";
    //if (!$app->input->exists('redirect_uri') || ! $app->input->exists('state')) {
    //  $this->msg='Qualcosa è andato storto, riprova.';
    //  return parent::display($tpl);
    //}

    if($id != 0)  {
      //User is logged in
      $url=JUri::getInstance();
      $matches = array();
      preg_match('/(https?:\/\/).*?(\/.*)/', $url, $matches);
      $this->msg=$url.$matches."<br>";

      $token = $this->random_str(255);
      $db = JFactory::getDbo();
      $query = $db->getQuery(true);

      $columns = array('token', 'user_id');
      $values = array($db->quote($token), $db->quote($id));
      $query
        ->insert($db->quoteName('#__LoginTokens'))
        ->columns($db->quoteName($columns))
        ->values(implode(',', $values))
        ->on

      $db->setQuery($query);
      $db->execute();

      $query = $db->getQuery(true);

      $query
        ->select($db->quoteName('*'))
        ->from($db->quoteName('#__LoginTokens'));
      $query .= ' ON DUPLICATE KEY UPDATE ' . $db->quoteName('exp') . ' = ' . $db->quote('DEFAULT');

      $db->setQuery($query);
      $row = $db->loadRowList();
      $this->msg=var_dump($row);

      return parent::display($tpl);
    }

    $this->msg='Esegui il login con le credenziali della tua scuola per continuare.';

		parent::display($tpl);
	}
}
